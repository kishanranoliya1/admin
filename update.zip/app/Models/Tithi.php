<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tithi extends Model
{
    protected $table="tithi";
    public $timestamps = false;

    protected $fillable = [
        'start_degree',
        'end_degree',	
        'tithi_name',	
        'tithi_id',	
        'paksha',
        'shiva_vaas'
    ];

}
