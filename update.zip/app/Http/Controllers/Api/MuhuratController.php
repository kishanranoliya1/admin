<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Traits\CommonTrait;
use Auth;
use DB;
use App\Http\Controllers\Api\Controller;
use Carbon\Carbon;
use DateTime;

class MuhuratController extends Controller
{    
    use CommonTrait;
    public function getBrahmapMuhurta(Request $request){
        try {
            $user = Auth::guard('api')->user();
            if ($user) {
                $request->request->add(['api_id' => 37]);
               $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                $timezoneMin=60*$request->tzone;

                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;

                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                $sunrise = $this->getSunrise($date,$latlng);   
                $sunset = $this->getSunset($previousDate,$latlng);
                $startDate = Carbon::parse(trim($date." ".$sunrise));
                $startDate->addMinutes($timezoneMin);
                $start = round(($this->getSunriseDifferentInMinutes("$previousDate ".$sunset,"$date ".$sunrise)/720)*48);
                $end = $start*2;

                $startDate->subMinutes($end);
                $startTime = $startDate->format('Y-m-d H:i:s');
                $startDate->addMinutes($end);
                $endTime = $startDate->subMinutes($start);
                $endTime = $endTime->format('Y-m-d H:i:s');

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);

            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getGodhuliMuhurta(Request $request){
        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 38]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE
                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                
                $sunrise = $this->getSunrise($date,$latlng);   
                $sunset = $this->getSunset($previousDate,$latlng);
                
                $startDate = Carbon::parse(trim($date." ".$sunset));
                $startDate->addMinutes($timezoneMin);
                $start = round(($this->getSunriseDifferentInMinutes("$previousDate ".$sunset,"$date ".$sunrise)/720)*24);   
                
                $startTime = $startDate->format('Y-m-d H:i:s');
                $endTime = $startDate->addMinutes($start);
                $endTime = $endTime->format('Y-m-d H:i:s');

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getPratahSandhya(Request $request){
        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 39]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE
                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                $nextDate = $this->getNextDate($date);
                
                $sunrise = $this->getSunrise($nextDate,$latlng);   
                $sunset = $this->getSunset($date,$latlng);
                
                $startDate = Carbon::parse(trim($date." ".$this->getSunrise($date,$latlng)));
                $startDate->addMinutes($timezoneMin);
                $start = round((($this->getSunriseDifferentInMinutes("$date ".$sunset,"$nextDate ".$sunrise)/720)*24)*3);   
                $endTime = $startDate->format('Y-m-d H:i:s');
                $startDate->subMinutes($start);
                $startTime = $startDate->format('Y-m-d H:i:s');

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getSayahanaSandhya(Request $request){
        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 40]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE
                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                $nextDate = $this->getNextDate($date);
                
                $sunrise = $this->getSunrise($nextDate,$latlng);   
                $sunset = $this->getSunset($date,$latlng);
                
                $startDate = Carbon::parse(trim($date." ".$this->getSunset($date,$latlng)));
                $startDate->addMinutes($timezoneMin);
                $start = round((($this->getSunriseDifferentInMinutes("$date ".$sunset,"$nextDate ".$sunrise)/720)*24)*3);   
                $startTime = $startDate->format('Y-m-d H:i:s');
                $startDate->addMinutes($start);
                $endTime = $startDate->format('Y-m-d H:i:s');

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getNishitaMuhurta(Request $request){
        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 41]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE
                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                $nextDate = $this->getNextDate($date);
                
                $sunrise = $this->getSunrise($nextDate,$latlng);   
                $sunset = $this->getSunset($date,$latlng);
                
                $startDate = Carbon::parse(trim($date." ".$this->getSunset($date,$latlng)));
                $startDate->addMinutes($timezoneMin);
                $start = round((($this->getSunriseDifferentInMinutes("$date ".$sunset,"$nextDate ".$sunrise)/720)*48)*7);   
                $startDate->addMinutes($start);
                $startTime = $startDate->format('Y-m-d H:i:s');
                $startDate->addMinutes(round(($this->getSunriseDifferentInMinutes("$date ".$sunset,"$nextDate ".$sunrise)/720)*48));
                $endTime = $startDate->format('Y-m-d H:i:s');

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getVijayMuhurta(Request $request){
        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 42]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE
                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                $nextDate = $this->getNextDate($date);
                
                $sunrise = $this->getSunrise($date,$latlng);   
                $sunset = $this->getSunset($date,$latlng);
                
                $startDate = Carbon::parse(trim($date." ".$this->getSunrise($date,$latlng)));
                $startDate->addMinutes($timezoneMin);
                $start = round((($this->getSunriseDifferentInMinutes("$date ".$sunrise,"$date ".$sunset)/720)*48)*10);   
                $startDate->addMinutes($start);
                $startTime = $startDate->format('Y-m-d H:i:s');
                $startDate->addMinutes(round(($this->getSunriseDifferentInMinutes("$date ".$sunrise,"$date ".$sunset)/720)*48));
                $endTime = $startDate->format('Y-m-d H:i:s');

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getAbhijitMuhurta(Request $request){
        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 43]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE

                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
    
                $sunrise = $this->getSunrise($date,$latlng);   
                $sunset = $this->getSunset($date,$latlng);
    
                $startDate = Carbon::parse(trim($date." ".$sunrise));            
                $startDate->addMinutes($timezoneMin);
                
                $start = round(($this->getSunriseDifferentInMinutes("$date ".$sunrise,"$date ".$sunset)/720)*24);
                $startDate->addMinutes($this->getSunriseDifferentInMinutes("$date ".$sunrise,"$date ".$sunset)/2);
    
                $startDate->subMinutes($start);
                $startTime = $startDate->format('Y-m-d H:i:s');
                $startDate->addMinutes($start*2);
                $endTime = $startDate->format('Y-m-d H:i:s');

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
    
            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getChandramasa(request $request) {

        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 44]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
            $api_key  = $request->api_key;
            $day = $request->day;
            $month = $request->month;
            $year = $request->year;
            $lat = $request->lat;
            $lon = $request->lon;
            $tzone = $request->tzone;

            $date = $day.'.'.$month.'.'.$year;
            // $date = "22.2.2024";
            // $latlng = "72.8311,21.1702";
            $latlng = $lon.','.$lat;
            $sunrise = $this->swetest->query("-b$date -rise -geopos$latlng -g, -head")->execute()->response();
            $sunrise = $sunrise['output'][1];
            $sunrise_sunset_data = $this->swetest->query("-b$date -ut".trim(explode(",",$sunrise)[2])." -p01 -fPZBsdalT -geopos$latlng -n30 -s-1d -sid -g, -head")->execute()->response();
            $str = $sunrise_sunset_data['output'];
            $month= "";
            $adhik = false;
            
            $tithis = DB::table('tithi')->get();
            $signs = array(
                'sa' => 'Pausha',
                'cp' => 'Magha',
                'aq' => 'Phalguna',
                'ar' => 'Vaisakh',
                'li' => 'Kartik',
                'sc' => 'Margashirsha',
                'vi' => 'Ashvina',
                'ta' => 'Jyeshtha',
                'pi' => 'Chaitra',
                'ge' => 'Ashaada',
                'le' => 'Bhadrapada',
                'cn' => 'Shraavana'
            );
            for($i = 0;$i<count($str);$i+=2){
                $sunData = explode(',',$str[$i]);
                $moonData = explode(',',$str[$i+1]);
                $total_sun_moon = $moonData[6] - $sunData[6];
                if($total_sun_moon < 0)
                {
                    $total_sun_moon = 360 - ($sunData[6]-$moonData[6]);    
                }
                $tithi = $this->findTithiFromDegree($tithis,$total_sun_moon);
                if($tithi->tithi_name == 'Pratipada' && $tithi->paksha == 'Shukla'){
                
                    foreach(explode(" ",$sunData[1]) as $word)
                    {
                        if(array_key_exists($word,$signs))
                        {
                            $month = $signs[$word];
                        }
                    }
                }
            }
            

            $sunrise_sunset_data = $this->swetest->query("-b$date -ut".trim(explode(",",$sunrise)[2])." -p01 -fPZBsdalT -geopos$latlng -n30 -s1d -sid -g, -head")->execute()->response();
            $str = $sunrise_sunset_data['output'];
            for($i = 0;$i<count($str);$i+=2){
                $sunData = explode(',',$str[$i]);
                $moonData = explode(',',$str[$i+1]);
                $total_sun_moon = $moonData[6] - $sunData[6];
                if($total_sun_moon < 0)
                {
                    $total_sun_moon = 360 - ($sunData[6]-$moonData[6]);    
                }
                $tithi = $this->findTithiFromDegree($tithis,$total_sun_moon);
                if($tithi != null)
                {
                if($tithi->tithi_name == 'Pratipada' && $tithi->paksha == 'Shukla'){
                
                    foreach(explode(" ",$sunData[1]) as $word)
                    {
                        if(array_key_exists($word,$signs))
                        {
                            if($signs[$word] == $month)
                            {
                                $adhik = true;
                            }
                        }
                    }
                }
            }
            }
        return response()->json(['status'=>true,'chandramasa'=>array('month'=>$month,'aadhik'=>$adhik)]);
            
            } else {
            
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);

            }

        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {

            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);

        }
	}

    public function getTriPushkaraYoga(Request $request){
        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 45]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE
                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                $nextDate = $this->getNextDate($date);
                
                $sunrise = $this->getSunrise($date,$latlng);                   
                $startDate = Carbon::parse(trim($date." ".$this->getSunrise($date,$latlng)));
                $startDate->addMinutes($timezoneMin);
                $startTime = null;
                $endTime = null;
                if(in_array($startDate->format('l'),array("Sunday","Tuesday","Saturday")))
                {       
                    foreach($this->getTithi($date,$latlng) as $tithi => $tithiTimes)
                    {
                        if(in_array($tithi,array("Dwitiya","Saptami","Dwadashi")))
                        {
                            foreach($this->getNakshtra($date,$latlng) as $nakshtra => $nakshtraTimes)
                            {
                                if(in_array($nakshtra,array("Uttara Phalguni","Vishakha","Purva Bhadrapada","Punarvasu","Krittika","Uttara Ashada")))
                                {
                                    if(new DateTime($tithiTimes['start_time']) > new DateTime($nakshtraTimes['start_time']))
                                    {
                                        $startTime = $tithiTimes['start_time'];
                                    }
                                    else if(new DateTime($tithiTimes['start_time']) < new DateTime($nakshtraTimes['start_time'])){
                                        $startTime = $nakshtraTimes['start_time'];
                                    }
                                    else if(new DateTime($tithiTimes['start_time']) == new DateTime($nakshtraTimes['start_time']))
                                    {
                                        $startTime = $tithiTimes['start_time'];
                                    }

                                    if(new DateTime($tithiTimes['end_time']) > new DateTime($nakshtraTimes['end_time']))
                                    {
                                        $endTime = $nakshtraTimes['end_time'];
                                    }
                                    else if(new DateTime($tithiTimes['end_time']) < new DateTime($nakshtraTimes['end_time'])){
                                        $endTime = $tithiTimes['end_time'];
                                    }
                                    else if(new DateTime($tithiTimes['end_time']) == new DateTime($nakshtraTimes['end_time']))
                                    {
                                        $endTime = $tithiTimes['end_time'];
                                    }
                                }
                            }
                        }
                    }
                    $startDate = Carbon::parse($startTime);
                    $startDate->addMinutes($timezoneMin);
                    $startTime = $startDate->format('Y-m-d H:i:s');

                    $endDate = Carbon::parse($endTime);
                    $endDate->addMinutes($timezoneMin);
                    $endTime = $endDate->format('Y-m-d H:i:s');
                }
                // dd($start_time,$end_time);
                

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getAmritSiddhiYoga(Request $request){
        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 46]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE
                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                $nextDate = $this->getNextDate($date);
                
                $sunrise = $this->getSunrise($date,$latlng);                   
                $startDate = Carbon::parse(trim($date." ".$this->getSunrise($date,$latlng)));
                $startDate->addMinutes($timezoneMin);
                $amritSiddhiYogaWithDayName = array('Sunday'=>'Hasta','Monday'=>'Mrigshira','Tuesday'=>'Aswini','Wednesday'=>'Anuradha','Thursday'=>'Pushya','Friday'=>'Revati','Saturday'=>'Rohini');
                $currentDayName = $startDate->format('l');
                $currentNakshtra = $this->getNakshtra($date,$latlng);
                
                $amritSiddhiYogaWithDayName = isset($currentNakshtra[$amritSiddhiYogaWithDayName[$currentDayName]]) ? $currentNakshtra[$amritSiddhiYogaWithDayName[$currentDayName]] : null ;

                if($amritSiddhiYogaWithDayName != null)
                {

                    $startDate = Carbon::parse($amritSiddhiYogaWithDayName['start_time']);
                    $startDate->addMinutes($timezoneMin);
                    $startTime = $startDate->format('Y-m-d H:i:s');
                    
                    $endDate = Carbon::parse($amritSiddhiYogaWithDayName['end_time']);
                    $endDate->addMinutes($timezoneMin);
                    $endTime = $endDate->format('Y-m-d H:i:s');
                
                }
                else{
                    $startTime = "";
                    $endDate = "";
                }

                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
            } else {
    
                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function getAmritKalamYoga(Request $request){


        try {
    
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
                $request->request->add(['api_id' => 47]);
                //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE
                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                $previousDate = $this->getPreviousDate($date);
                $nextDate = $this->getNextDate($date);
                
                $todaySunrise = Carbon::parse($date." ".$this->getSunrise($date,$latlng));     
                $todaySunrise->addMinutes($timezoneMin);              

                $tomorrowSunrise = Carbon::parse($nextDate." ".$this->getSunrise($nextDate,$latlng));                   
                $tomorrowSunrise->addMinutes($timezoneMin);              

                $startDate = Carbon::parse(trim($date." ".$this->getSunrise($date,$latlng)));
                $startDate->addMinutes($timezoneMin);

                $currentNakshtra = $this->getNakshtraForAmritKalam($date,$latlng);
                
                $nakshtraHours = array(
                    'Aswini' => 16.8,
                    'Bharani' => 19.2,
                    'Krittika' => 21.6,
                    'Rohini' => 20.8,
                    'Mrigashira' => 15.2,
                    'Ardra' => 14,
                    'Punarvasu' => 21.6,
                    'Pushya' => 17.6,
                    'Ashlesha' => 22.4,
                    'Magha' => 21.6,
                    'Purva Phalguni' => 17.6,
                    'Uttara Phalguni' => 16.8,
                    'Hasta' => 18,
                    'Chitra' => 17.6,
                    'Swati' => 15.2,
                    'Vishakha' => 15.2,
                    'Anuradha' => 13.6,
                    'Jyeshtha' => 15.2,
                    'Moola' => 17.6,
                    'Purva Ashada' => 19.2,
                    'Uttara Ashada' => 17.6,
                    'Shravana' => 13.6,
                    'Dhanishtha' => 13.6,
                    'Shatabhisha' => 16.8,
                    'Purva Bhadrapada' => 16,
                    'Uttara Bhadrapada' => 19.2,
                    'Revati' => 21.6
                );

                $amritKalam = array();
                foreach($currentNakshtra as $nakshtra => $nakshtraTime)
                {
                   
                    
                    

                    $startTime = Carbon::parse($nakshtraTime['start_time']);
                    $startTime->addMinutes($timezoneMin);
                    $endTime = Carbon::parse($nakshtraTime['end_time']);
                    $endTime->addMinutes($timezoneMin);
                    
                    // $minutes = (($endTime->diffInMinutes($startTime)/1440) * ($nakshtraHours[$nakshtra])) ;
                    
                    $minutes = 0;
                    // // $startTimeInMinutes = (($nakshtraHours[$nakshtra]/24)*$minutes);
                    
                    
                    //  $startTime->addMinutes($minutes);
                    // if($startTime->between($todaySunrise,$tomorrowSunrise))
                    // {
                        $amritKalam[]=['start_time'=>$startTime->format('Y-m-d H:i:s'),'end_time'=>$endTime->format('Y-m-d H:i:s'),'duration'=>$endTime->diffInMinutes($startTime),'minutes'=>$minutes];
                        // $amritKalam[]=['start_time'=>$carbonInstance->format('Y-m-d H:i:s'),'end_time'=>$carbonInstance->addMinutes($timezoneMin)->addMinutes((($nakshtraHours[$nakshtra]/24)*1.6))->format('Y-m-d H:i:s')];
                    // }
                }
                // dd($currentNakshtra,$amritKalam);
                
                return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
            } else {

                //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
    
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }

    public function findTithiFromDegree($tithis,$degree)
    {
        foreach($tithis as $key => $value)
        {
            if($value->degree_start <= $degree && $value->degree_end >= $degree)
            {
                return $value;
            }
        }
        return null;
    }

    public function getTithi($date,$latlng)
    {
        $total_time = [];
        $tithiList = DB::table('vedic_tithi')->get();
        $str = $this->getDegreeWithTime($date,$latlng,(24*60),"1m");
        $classification = array();
        for($i = 0;$i<count($str);$i+=2){
            $sunData = explode(',',$str[$i]);                
            $moonData = explode(',',$str[$i+1]);
            $total_sun_moon = $moonData[1] - $sunData[1];
            if($total_sun_moon < 0)
            {
                $total_sun_moon = 360 - ($sunData[1]-$moonData[1]);    
            }
            $tithi = $this->findTithiFromDegree($tithiList,$total_sun_moon);
            $sunData_time = $sunData[2];
            $moonData_time = $moonData[2];
            $tithi_name = $tithi->tithi;
            $total_time[$tithi_name][] = $sunData_time;
            $classification[$tithi_name] = $tithi->classification;
        }

        foreach($total_time as $key => $val)
        {
            $startDate = Carbon::parse(trim(str_replace("UT","",$val[0])));
            $endDate = Carbon::parse(trim(str_replace("UT","",$val[count($val)-1])));
            if((!(new DateTime($startDate->format('d.m.Y')) > new DateTime($date)) && !(new DateTime($startDate->format('d.m.Y')) < new DateTime($date))) || (!(new DateTime($endDate->format('d.m.Y')) > new DateTime($date)) && !(new DateTime($endDate->format('d.m.Y')) < new DateTime($date)))  )
            {
                $startDate = $startDate->format('Y-m-d H:i:s');
                $endDate = $endDate->format('Y-m-d H:i:s');
                $tithis[$key] = ['start_time'=>$startDate,'end_time'=>$endDate,'classification'=>$classification[$key]];
            }

        }
        return $tithis;
    }

    public function getNakshtra($date,$latlng)
    {
                $nakshatra = DB::table('sun_nakshatra')->get();
                $start_time = null;
                $end_time = null;
                $str = $this->getDegreeWithTime($date,$latlng,1560,"1m"); // 1560 = 24*60
                $currentNakshatra = array();
                for($i = 0;$i<count($str);$i+=2){
                    $moonData = explode(',',$str[$i+1]);
                    $total_moon = $moonData[1];
                    $moon_nakshatra = $this->findNakshatraNamefromTime($total_moon,$nakshatra);
                    $currentNakshatra[$moon_nakshatra][]=$moonData[2];
                }
                $temp = array();
                foreach($currentNakshatra as $key => $val)
                {                   
                    
                    $temp[$key]['start_time'] = Carbon::parse(trim(str_replace("UT","",$val[0])))->format('Y-m-d H:i:s');;
                    $temp[$key]['end_time'] = Carbon::parse(trim(str_replace("UT","",$val[count($val)-1])))->format('Y-m-d H:i:s');;
                }
                $currentNakshatra = $temp;
                return $currentNakshatra;

    }

    public function getNakshtraForAmritKalam($date,$latlng)
    {
                $nakshatra = DB::table('sun_nakshatra')->get();
                $diffMinute = $this->getSunriseDifferentInMinutes($this->getPreviousDate($date)." ".$this->getSunset($this->getPreviousDate($date),$latlng),$this->getNextDate($date)." ".$this->getSunset($this->getNextDate($date),$latlng));
                $str = $this->getDegreeWithCustomTime($this->getPreviousDate($date),$this->getSunset($this->getPreviousDate($date),$latlng),$latlng,$diffMinute,"1m"); // 1560 = 24*60
                $currentNakshatra = array();
                for($i = 0;$i<count($str);$i+=2){
                    $moonData = explode(',',$str[$i+1]);
                    $total_moon = $moonData[1];
                    $moon_nakshatra = $this->findNakshatraNamefromTime($total_moon,$nakshatra);
                    $currentNakshatra[$moon_nakshatra][]=$moonData[2];
                }
                $temp = array();

                // $startDate = Carbon::parse($date." ".$this->getSunrise($date,$latlng));
                // $endDate = Carbon::parse($this->getNextDate($date)." ".$this->getSunrise($this->getNextDate($date),$latlng));
                foreach($currentNakshatra as $key => $val)
                {                   
                    // if(Carbon::parse(trim(str_replace("UT","",$val[0])))->between($startDate,$endDate))
                    // {
                        $temp[$key]['start_time'] = Carbon::parse(trim(str_replace("UT","",$val[0])))->format('Y-m-d H:i:s');
                        $temp[$key]['end_time'] = Carbon::parse(trim(str_replace("UT","",$val[count($val)-1])))->format('Y-m-d H:i:s');
                    // }
                }

                $currentNakshatra = $temp;
                return $currentNakshatra;

    }

    public function findNakshatraNamefromTime($time,$data)
    {
        foreach($data as $key => $value)
        {
            if($value->start_nakshatra <= $time && $value->end_nakshatra >= $time)
            {
                return $value->nakshatra_name;
            }
        }
        return null;
    } 

}

