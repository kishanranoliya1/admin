<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApiLog extends Model
{
    protected $connection = '';  
    public $timestamps = false;  
    
    protected $fillable = [
        'client_id',
        'api_id',
        'call_on',
        'ip_addr',
        'domain',
        'os_platform',
        'device',
        'browser',
    ];

    public function __construct() {

        if (env('APP_ENV') == 'local') {
            //Test Database
            $this->connection = 'mysql2';
        } else {
            //Live Database
            $this->connection = 'mysql3';
        }

    }

}
