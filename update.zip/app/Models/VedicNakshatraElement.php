<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VedicNakshatraElement extends Model
{
    protected $table="vedic_nakshatra_element";
    public $timestamps = false;

    protected $fillable = [
        'nak_name',
        'lord',	
        'deity',	
        'element',	
        'symbol',	
        'syllables',
        'pursuit',	
        'gana',	
        'direction',
        'guna',	
        'body_part',
        'color',
    ];

}
