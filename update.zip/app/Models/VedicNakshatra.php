<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VedicNakshatra extends Model
{
    protected $table="vedic_nakshtra";
    public $timestamps = false;

    protected $fillable = [
        'zodiac_short_name',
        'start_point',
        'end_point',
        'nakshtra_id',
        'nakshatra_name',
        'pada_number',
        'pada_start_point',
        'pada_end_point',
    ];

    public static function getVedicNakshatra() {
        $data = self::select(
            'vedic_nakshtra.*',
            'vedic_nakshatra_element.nak_name',
            'vedic_nakshatra_element.lord',
            'vedic_nakshatra_element.deity',
            'vedic_nakshatra_element.element',
            'vedic_nakshatra_element.symbol',
            'vedic_nakshatra_element.syllables',
            'vedic_nakshatra_element.pursuit',
            'vedic_nakshatra_element.gana',
            'vedic_nakshatra_element.direction',
            'vedic_nakshatra_element.guna',
            'vedic_nakshatra_element.body_part',
            'vedic_nakshatra_element.color',
        )->join('vedic_nakshatra_element', 'vedic_nakshatra_element.id', '=', 'vedic_nakshtra.nakshtra_id')
        ->get();
        $final_data = [];
        $first_nakshatra = "";
        $last_zodiac = "";
        $last_nakshatra = "";
        $pada = [];
        foreach($data as $key=>$d){
            if($key != 0 
            && ($last_zodiac != $d->zodiac_short_name
            || $last_nakshatra != $d->nakshatra_name)){
                $fetch_data = $data[$key - 1];
                $nakshatra['start_point'] = $fetch_data->start_point;
                $nakshatra['end_point'] = $fetch_data->end_point;
                $nakshatra['nak_number'] = $fetch_data->nakshtra_id;
                $nakshatra['nak_name'] = $fetch_data->nak_name;
                $nakshatra['lord'] = $fetch_data->lord;
                $nakshatra['deity'] = $fetch_data->deity;
                $nakshatra['element'] = $fetch_data->element;
                $nakshatra['symbol'] = $fetch_data->symbol;
                $nakshatra['syllables'] = $fetch_data->syllables;
                $nakshatra['pursuit'] = $fetch_data->pursuit;
                $nakshatra['gana'] = $fetch_data->gana;
                $nakshatra['direction'] = $fetch_data->direction;
                $nakshatra['guna'] = $fetch_data->guna;
                $nakshatra['body_part'] = $fetch_data->body_part;
                $nakshatra['color'] = $fetch_data->color;
                $nakshatra['pada'] = $pada;
                $naskhatra_data[$fetch_data->zodiac_short_name][] = $nakshatra;
                $pada = [];
            }
            $last_zodiac = $d->zodiac_short_name;
            $last_nakshatra = $d->nakshatra_name;
            $pada[] = [
                'pada' => $d->pada_number,
                'start_point' => $d->pada_start_point,
                'end_point' => $d->pada_end_point,
            ];
        }
        $fetch_data = $data[$key];
        $nakshatra['start_point'] = $fetch_data->start_point;
        $nakshatra['end_point'] = $fetch_data->end_point;
        $nakshatra['nak_number'] = $fetch_data->nakshtra_id;
        $nakshatra['nak_name'] = $fetch_data->nak_name;
        $nakshatra['lord'] = $fetch_data->lord;
        $nakshatra['deity'] = $fetch_data->deity;
        $nakshatra['element'] = $fetch_data->element;
        $nakshatra['symbol'] = $fetch_data->symbol;
        $nakshatra['syllables'] = $fetch_data->syllables;
        $nakshatra['pursuit'] = $fetch_data->pursuit;
        $nakshatra['gana'] = $fetch_data->gana;
        $nakshatra['direction'] = $fetch_data->direction;
        $nakshatra['guna'] = $fetch_data->guna;
        $nakshatra['body_part'] = $fetch_data->body_part;
        $nakshatra['color'] = $fetch_data->color;
        $nakshatra['pada'] = $pada;
        $naskhatra_data[$fetch_data->zodiac_short_name][] = $nakshatra;
        return $naskhatra_data;
    }

}
