<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VedicKarana extends Model
{
    protected $table="vedic_karana";
    public $timestamps = false;

    protected $fillable = [
        'id',
        'tithi_id',
        'karana_name',
        'start_point',
        'end_point',
    ];

    public static function getVedicKarana() {
        return self::select(
            'vedic_karana.*',
            'vedic_tithi.tithi',
            'vedic_tithi.paksha'
        )->join('vedic_tithi', 'vedic_tithi.id', '=', 'vedic_karana.tithi_id')
        ->get()->toArray();
    }

}
