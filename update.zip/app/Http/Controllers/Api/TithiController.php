<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Traits\CommonTrait;
use Auth;
use Carbon\Carbon;
use App\Http\Controllers\Api\Controller;
use DB;
use Log;
class NakshatraController extends Controller
{    
    use CommonTrait;
    public function getNakshatra(Request $request){
        try {
            $user = Auth::guard('api')->user();
            if ($user) {
    
            //ENTER API ID 36 FOR YOUR FIRST API AND THEN INCREASE BY ONE FOR OTHER APIS
            $request->request->add(['api_id' => 39]);
               //PASS FIELD NAMES YOU WANT TO VALIDATE 
                $rules = array('day', 'month', 'year', 'lat', 'lon', 'tzone');
                $resp = $this->validate_api_request($request, $rules, $user->id);
                if ($resp['success'] != 1) {
                    return response()->json($resp);
                } 
                
                //YOUR API LOGIC GOES HERE

                $api_key  = $request->api_key;
                $day = $request->day;
                $month = $request->month;
                $year = $request->year;
                $lat = $request->lat;
                $lon = $request->lon;
                $tzone = $request->tzone;
                $timezoneMin=60*$request->tzone;
                $date = $day.'.'.$month.'.'.$year;
                $latlng = $lon.','.$lat;
                
                $previousDate = $this->getPreviousDate($date);

                $nakshatra = DB::table('sun_nakshatra')->get();
                $timezoneMin=60*$request->tzone;
                $start_time = null;
                $end_time = null;
                $str = $this->getDegreeWithTime($date,$latlng,
                $this->getSunriseDifferentInMinutes($previousDate." ".$this->getSunset($previousDate,$latlng),$this->getNextDate($date)." ".$this->getSunset($this->getNextDate($date),$latlng)),
                "1m");
                
                for($i = 0;$i<count($str);$i+=2){
                    $sunData = explode(',',$str[$i]);
                    $moonData = explode(',',$str[$i+1]);
                    $total_sun = $sunData[1];
                    $total_moon = $moonData[1];
                    $sun_nakshatra = $this->findNakshatrafromTime($total_sun,$nakshatra);
                    $moon_nakshatra = $this->findNakshatrafromTime($total_moon,$nakshatra);
                    if($sun_nakshatra != null && $moon_nakshatra != null)
                    {
                        $diff = $this->findDifference($sun_nakshatra,$moon_nakshatra);
                        $findDiff = in_array($this->findDifference($sun_nakshatra,$moon_nakshatra),array(4,6,9,10,13,20));
                        LOG::info("$sunData[2] $total_sun $total_moon $diff - $findDiff");
                        if(in_array($this->findDifference($sun_nakshatra,$moon_nakshatra),array(4,6,9,10,13,20)) && $start_time == null)
                        {
                            $start_time = $sunData[2];
                        }

                        if((!in_array($this->findDifference($sun_nakshatra,$moon_nakshatra),array(4,6,9,10,13,20))) && $start_time != null)
                        {
                            $end_time = $sunData[2];   
                            break;
                        }
                    }
                }
                $startDate = Carbon::parse(trim(str_replace("UT","",$start_time)));
                $startDate->addMinutes($timezoneMin);
                $startTime = $startDate->format('Y-m-d H:i:s');
                if($startDate->format('d') ==  $request->day)
                {
                    $startDate = Carbon::parse(str_replace("UT","",trim($end_time)));
                    $startDate->addMinutes($timezoneMin);
                    $endTime = $startDate->format('Y-m-d H:i:s');
                    return response()->json(['success'=>1,"data"=>['start_time'=>$startTime,'end_time'=>$endTime]]);
                }
                else{
                    return response()->json(['success' => 1, "data"=>['start_time'=>"",'end_time'=>""]]);
                }

    
            } else {
                
                    //Bearer token not found
                return response()->json(['success' => 3, 'msg' => 'Invalid authorization token!']);
            
            }
    
        } catch (\Tymon\JWTAuth\Exception\UserNotDefinedException $e) {
    
            return response()->json(['success' => 4, 'msg' => $e->getMessage()]);
    
        }
    
    }
    

}

