<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DrikRituCalculation extends Model
{
    protected $table="drik_ritu_calculations";
    public $timestamps = false;

    protected $fillable = [
        'id',
        'name',
        'start_range',
        'end_range',
    ];

}
