<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sign extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'id',
        'sign',
        'code',
        'ayana',
        'image',
        'image2',
    ];

}
