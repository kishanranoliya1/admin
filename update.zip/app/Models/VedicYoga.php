<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VedicYoga extends Model
{
    protected $table="vedic_yoga";
    public $timestamps = false;

    protected $fillable = [
        'id',
        'yoga_name',
    ];

}
