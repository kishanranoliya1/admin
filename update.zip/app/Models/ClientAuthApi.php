<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientAuthApi extends Model
{
    protected $table="client_auth_api";
    public $timestamps = false;

    protected $fillable = [
        'client_id',
        'api_id',
        'subscription_end_date',
        'subscription_amount',
        'is_grace_period',
        'note',
    ];

    // public static function get_subscription_end_date_by_client_id($client_id) {

    //     return self::select('')->where('api_key', $api_key)->first();

    // }

}
