<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VedicBhadraNiwas extends Model
{
    protected $table="vedic_bhadra_niwas";
    public $timestamps = false;

    protected $fillable = [
        'id',
        'moon_placement',
        'zodiac_name',
        'bhadra_niwas',
        'nature',
    ];

}
