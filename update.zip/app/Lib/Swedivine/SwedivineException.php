<?php

namespace App\Lib\Swedivine;

class SwedivineException extends \Exception {



}