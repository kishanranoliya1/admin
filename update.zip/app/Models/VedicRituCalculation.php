<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VedicRituCalculation extends Model
{
    protected $table="vedic_ritu_calculations";
    public $timestamps = false;

    protected $fillable = [
        'id',
        'name',
        'start_range',
        'end_range',
    ];

}
