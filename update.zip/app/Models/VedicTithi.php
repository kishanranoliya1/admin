<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VedicTithi extends Model
{
    protected $table="vedic_tithi";
    public $timestamps = false;

    protected $fillable = [
        'degree_start',
        'degree_end',	
        'tithi',	
        'paksha',	
        'classification'
    ];

}
